'use client';

import React, { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';


function Header({ onToggleSidebar }) {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef(null);

  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="p-0">
      <div className="header-inner">
        <div className="page-title">
          <button
            id="toggleBtn"
            className="btn btn-outline-secondary me-2"
            aria-label="Toggle sidebar"
            onClick={onToggleSidebar}
          >
            ☰
          </button>
          <h4 className="mb-0">Admin Panel</h4>
        </div>
        <div className="header-actions d-flex align-items-center">
          <div className="dropdown" ref={dropdownRef}>
            <a
              href="#"
              className="d-flex align-items-center text-decoration-none dropdown-toggle"
              id="userDropdown"
              onClick={(e) => {
                e.preventDefault();
                setDropdownOpen(!dropdownOpen);
              }}
              aria-expanded={dropdownOpen}
            >
              <span className="me-2 d-none d-md-inline text-muted small">Admin</span>
              <img src="/assets/images/avatar.svg" alt="avatar"  className="avatar rounded-circle" />
            </a>
            <ul
              className={`dropdown-menu dropdown-menu-end ${dropdownOpen ? 'show' : ''}`}
              aria-labelledby="userDropdown"
            >
              <li>
                <Link to="/" className="dropdown-item text-danger">
                  Logout
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </header>
  );
}

export default Header;
