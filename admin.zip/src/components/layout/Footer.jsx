import React from 'react';

function Footer() {
  return (
    <footer className="p-3 border-top text-center small text-muted">
      Appointment Hub
    </footer>
  );
}

export default Footer;
