import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Partners from './pages/Partners';
import AddPartner from './pages/AddPartner';
import Membership from './pages/Membership';
import AddMembership from './pages/AddMembership';
import Payments from './pages/Payments';
import Invoice from './pages/Invoice';
import AdminLayout from './components/layout/AdminLayout';

function App() {
  return (
    <Routes>
      <Route path="/" element={<Login />} />
      <Route path="/login" element={<Login />} />
      <Route element={<AdminLayout />}>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/partners" element={<Partners />} />
        <Route path="/add-partner" element={<AddPartner />} />
        <Route path="/membership" element={<Membership />} />
        <Route path="/add-membership" element={<AddMembership />} />
        <Route path="/payments" element={<Payments />} />
        <Route path="/invoice" element={<Invoice />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default App;
