'use client';

import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

function AddMembership() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    price: '',
    duration: '15 Days',
    status: 'Active',
    benefits: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission logic here
    navigate('/membership');
  };

  return (
    <div className="card mb-3">
      <div className="card-header d-flex justify-content-between align-items-center">
        <strong>Add New Membership Plan</strong>
        <div>
          <Link to="/membership" className="btn btn-primary">
            <i className="fa fa-eye"></i> View All
          </Link>
        </div>
      </div>

      <div className="card-body">
        <form onSubmit={handleSubmit}>
          <div className="row">
            <div className="col-md-6 mb-3">
              <label className="form-label">Plan Name</label>
              <input
                type="text"
                name="name"
                className="form-control"
                placeholder="Enter plan name"
                value={formData.name}
                onChange={handleChange}
              />
            </div>

            <div className="col-md-6 mb-3">
              <label className="form-label">Price (₹)</label>
              <input
                type="number"
                name="price"
                className="form-control"
                placeholder="Enter price"
                value={formData.price}
                onChange={handleChange}
              />
            </div>

            <div className="col-md-6 mb-3">
              <label className="form-label">Duration</label>
              <select
                name="duration"
                className="form-select"
                value={formData.duration}
                onChange={handleChange}
              >
                <option>15 Days</option>
                <option>1 Month</option>
                <option>3 Months</option>
                <option>6 Months</option>
                <option>1 Year</option>
              </select>
            </div>

            <div className="col-md-6 mb-3">
              <label className="form-label">Status</label>
              <select
                name="status"
                className="form-select"
                value={formData.status}
                onChange={handleChange}
              >
                <option>Active</option>
                <option>Inactive</option>
              </select>
            </div>

            <div className="col-md-12 mb-3">
              <label className="form-label">Benefits</label>
              <textarea
                name="benefits"
                className="form-control"
                rows="3"
                placeholder="Example: Unlimited appointments, priority support"
                value={formData.benefits}
                onChange={handleChange}
              ></textarea>
            </div>
          </div>

          <div className="mt-3">
            <button type="submit" className="btn btn-primary">
              <i className="fa fa-save"></i> Save Membership
            </button>
            <Link to="/membership" className="btn btn-secondary ms-2">
              Cancel
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
}

export default AddMembership;
